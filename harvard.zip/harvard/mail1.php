<?php
//get data from form  
$facility = $_POST['facility'];
$email= $_POST['email'];
$date= $_POST['date'];
$unit= $_POST['unit'];
$guests= $_POST['guests'];
$to = "pranavbm08@gmail.com";
$subject = "Mail From website";
$txt ="facility = ". $facility . "\r\n  Email = " . $email . "\r\n date  =" . $date;
$headers = "From: Livia website " . "\r\n";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thankyou.html");
?>