#FACILITY BOOKING SITE
#### Video Demo: https://youtu.be/eMV20_QDnhk
#### Description: I created a facility booking site for my condo . The booking site inclides an html form
 in which the resident inputs his/her personal info . Once the form is submitted a mail is directly sent 
 to my mail . The mail includes all the details provided by the resident (email , unit number , facility ,
  date , time and number of guests).I also made two fields of the form necessary , email and time .

I used bootsrap and css to design my home page . For the form i used basic input values like (text , date , email amd time)
.I used the php mail function to send the mail . I gave names to all the input values of the form and assigned them to 
variables in the php page , then i printed those variables  with the help of the mail function . I had to get an SMTP 
approval to be able to send gmails .

So essentially the aim of my webiste is for me to recieve booking requests from other residents of this condo and upon 
receiving it i can approve the request and the residents will be allowed to use the facilities.