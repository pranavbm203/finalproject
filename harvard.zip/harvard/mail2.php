<?php

$UN = $_POST['unit'];
$fac = $_POST['facility'];
$Email = $_POST['email'];
$Date = $_POST['date'];
$Time = $_POST['time'];
$Guests = $_POST['guests'];
$Subject = "Booking request for:".$fac.",by UNIT:".$UN;
$to = "pranavbm08@gmail.com";
$body="";

$body.="Unit: ".$UN."\r\n";
$body.="Facility: ".$fac."\r\n"; 
$body.="Email: ".$Email."\r\n";
$body.="Date: ".$Date."\r\n";
$body.="Time: ".$Time."\r\n";
$body.="NO.of guests: ".$Guests."\r\n";

mail($to,$Subject,$body)

?> 